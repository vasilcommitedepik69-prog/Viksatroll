using System.Collections.Concurrent;
using System.Net;
using System.Text.Json;
using System.Runtime.InteropServices;
using Discord;
using Discord.WebSocket;
using Color = Discord.Color;

var token = Environment.GetEnvironmentVariable("DISCORD_TOKEN")
    ?? throw new InvalidOperationException("Set the DISCORD_TOKEN environment variable.");
var youtubeKey = Environment.GetEnvironmentVariable("YOUTUBE_API_KEY");

using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
// GitHub and Wikipedia require a descriptive User-Agent
http.DefaultRequestHeaders.UserAgent.ParseAdd("MyDiscordBot/1.0 (Discord bot)");

// The sites users can pick from. The key is the dropdown label; the value is the
// website link. Discord allows up to 25 choices.
// To add a site: add a line here with its link, then add a matching case in
// RunSearchAsync (further down) that points to a handler for that site.
var sites = new Dictionary<string, string>();

if (!string.IsNullOrWhiteSpace(youtubeKey))
    sites["youtube.com"] = "https://www.youtube.com";
else
    Console.WriteLine("YOUTUBE_API_KEY not set, so YouTube is disabled.");

sites["wikipedia.com"] = "https://www.wikipedia.org";
sites["github.com"] = "https://github.com";
sites["news.ycombinator.com"] = "https://news.ycombinator.com";
sites ["call-phone"] = "callmyphone.org";

// Simple per-user cooldown so one person can't spam requests
var cooldowns = new ConcurrentDictionary<ulong, DateTime>();
var cooldown = TimeSpan.FromSeconds(10);

const string SelectMenuId = "site-select";
const string ModalPrefix = "search-modal:";

var client = new DiscordSocketClient(new DiscordSocketConfig
{
    GatewayIntents = GatewayIntents.Guilds // slash commands and components only need this
});

client.Log += msg =>
{
    Console.WriteLine(msg.ToString());
    return Task.CompletedTask;
};

// Register /summon. Overwriting replaces any older commands.
client.Ready += async () =>
{
    var summon = new SlashCommandBuilder()
        .WithName("summon")
        .WithDescription("Pick a website and look something up");

    await client.BulkOverwriteGlobalApplicationCommandsAsync(
        new ApplicationCommandProperties[] { summon.Build() });
};

// Step 1: /summon shows a private dropdown of websites
client.SlashCommandExecuted += async command =>
{
    if (command.CommandName != "summon") return;

    var menu = new SelectMenuBuilder()
        .WithCustomId(SelectMenuId)
        .WithPlaceholder("Choose a website...")
        .WithMinValues(1)
        .WithMaxValues(1);

    foreach (var name in sites.Keys)
        menu.AddOption(label: name, value: name);

    var components = new ComponentBuilder().WithSelectMenu(menu).Build();

    await command.RespondAsync("Which website do you want to use?",
        components: components, ephemeral: true);
};

// Step 2: after they pick a site, open a pop-up window asking for their text
client.SelectMenuExecuted += async component =>
{
    if (component.Data.CustomId != SelectMenuId) return;

    var site = component.Data.Values.First();

    // Never trust the incoming value: only allow sites from our list
    if (!sites.ContainsKey(site))
    {
        await component.RespondAsync("Unknown site.", ephemeral: true);
        return;
    }

    var modal = new ModalBuilder()
        .WithTitle($"Search {site}")
        .WithCustomId(ModalPrefix + site)
        .AddTextInput(
            label: "What do you want to look up?",
            customId: "query",
            style: TextInputStyle.Short,
            placeholder: "Type here...",
            maxLength: 100,
            required: true)
        .Build();

    await component.RespondWithModalAsync(modal);
};

// Step 3: they submitted the pop-up, so run the lookup, trigger screen automation, and post results
client.ModalSubmitted += async modal =>
{
    if (!modal.Data.CustomId.StartsWith(ModalPrefix)) return;

    var siteName = modal.Data.CustomId[ModalPrefix.Length..];
    var query = modal.Data.Components.First(c => c.CustomId == "query").Value.Trim();

    // Check again: modal IDs come from the client too
    if (!sites.TryGetValue(siteName, out var siteUrl) || query.Length == 0)
    {
        await modal.RespondAsync("Unknown site or empty search.", ephemeral: true);
        return;
    }

    // Cooldown check
    var now = DateTime.UtcNow;
    if (cooldowns.TryGetValue(modal.User.Id, out var last) && now - last < cooldown)
    {
        var wait = (int)Math.Ceiling((cooldown - (now - last)).TotalSeconds);
        await modal.RespondAsync($"Slow down! Try again in {wait}s.", ephemeral: true);
        return;
    }
    cooldowns[modal.User.Id] = now;

    // Acknowledge right away; Discord gives you only 3 seconds to respond
    await modal.DeferAsync();

    try
    {
        var embed = await RunSearchAsync(siteUrl, query);

        // --- Desktop Automation Trigger ---
        // 1. Click at X: 500, Y: 300 (e.g., focus a text field on your desktop app)
        DesktopAutomation.ClickAt(500, 300);
        System.Threading.Thread.Sleep(200);

        // 2. Type out the search query submitted from the modal
        DesktopAutomation.TypeText(query);
        System.Threading.Thread.Sleep(200);

        // 3. Click at X: 800, Y: 300 (e.g., hit a submit button)
        DesktopAutomation.ClickAt(800, 300);
        // ----------------------------------

        await modal.FollowupAsync(embed: embed);
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex);
        await modal.FollowupAsync($"Search failed for {siteName}. Try again in a bit.");
    }
};

await client.LoginAsync(TokenType.Bot, token);
await client.StartAsync();

// Keep the bot running
await Task.Delay(Timeout.Infinite);

// ---- Dispatcher ----
Task<Embed> RunSearchAsync(string siteUrl, string query)
{
    var host = new Uri(siteUrl).Host;
    if (host.StartsWith("www.")) host = host[4..];

    return host switch
    {
        "youtube.com" => SearchYouTubeAsync(query),
        var h when h == "wikipedia.com" || h.EndsWith("wikipedia.org") => SearchWikipediaAsync(query),
        "github.com" => SearchGitHubAsync(query),
        "news.ycombinator.com" => SearchHackerNewsAsync(query),
        _ => throw new NotSupportedException($"No search handler for {host} yet.")
    };
}

// ---- Helpers ----

async Task<JsonDocument> GetJsonAsync(string url, string? accept = null)
{
    using var request = new HttpRequestMessage(HttpMethod.Get, url);
    if (accept != null) request.Headers.Accept.ParseAdd(accept);
    using var response = await http.SendAsync(request);
    response.EnsureSuccessStatusCode();
    return JsonDocument.Parse(await response.Content.ReadAsStringAsync());
}

static string Str(JsonElement e, string name) =>
    e.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.String ? p.GetString() ?? "" : "";

static string Shorten(string s, int max) =>
    s.Length <= max ? s : s[..(max - 1)] + "…";

static Embed MakeEmbed(string title, string url, List<string> lines, Color color) =>
    new EmbedBuilder()
        .WithTitle(title)
        .WithUrl(url)
        .WithDescription(lines.Count > 0 ? string.Join("\n", lines) : "No results found.")
        .WithColor(color)
        .Build();

// ---- Site handlers ----

async Task<Embed> SearchYouTubeAsync(string query)
{
    var url = "https://www.googleapis.com/youtube/v3/search"
        + "?part=snippet&type=video&maxResults=5"
        + $"&q={Uri.EscapeDataString(query)}&key={youtubeKey}";

    using var doc = await GetJsonAsync(url);

    var lines = new List<string>();
    var i = 1;
    foreach (var item in doc.RootElement.GetProperty("items").EnumerateArray())
    {
        var id = item.GetProperty("id").GetProperty("videoId").GetString();
        var snippet = item.GetProperty("snippet");
        var title = Format.Sanitize(WebUtility.HtmlDecode(Str(snippet, "title")));
        var channel = Format.Sanitize(WebUtility.HtmlDecode(Str(snippet, "channelTitle")));
        lines.Add($"{i++}. [{title}](https://www.youtube.com/watch?v={id}) by {channel}");
    }

    return MakeEmbed($"YouTube results for \"{query}\"",
        $"https://www.youtube.com/results?search_query={Uri.EscapeDataString(query)}",
        lines, Color.Red);
}

async Task<Embed> SearchWikipediaAsync(string query)
{
    var url = "https://en.wikipedia.org/w/api.php"
        + "?action=opensearch&limit=5&namespace=0&format=json"
        + $"&search={Uri.EscapeDataString(query)}";

    using var doc = await GetJsonAsync(url);
    var titles = doc.RootElement[1];
    var links = doc.RootElement[3];

    var lines = new List<string>();
    for (var i = 0; i < titles.GetArrayLength(); i++)
    {
        var title = Format.Sanitize(titles[i].GetString() ?? "");
        lines.Add($"{i + 1}. [{title}]({links[i].GetString()})");
    }

    return MakeEmbed($"Wikipedia results for \"{query}\"",
        $"https://en.wikipedia.org/w/index.php?search={Uri.EscapeDataString(query)}",
        lines, Color.LightGrey);
}

async Task<Embed> SearchGitHubAsync(string query)
{
    var url = "https://api.github.com/search/repositories"
        + $"?per_page=5&q={Uri.EscapeDataString(query)}";

    using var doc = await GetJsonAsync(url, "application/vnd.github+json");

    var lines = new List<string>();
    var i = 1;
    foreach (var repo in doc.RootElement.GetProperty("items").EnumerateArray())
    {
        var name = Format.Sanitize(Str(repo, "full_name"));
        var link = Str(repo, "html_url");
        var stars = repo.GetProperty("stargazers_count").GetInt32();
        var description = Format.Sanitize(Shorten(Str(repo, "description"), 100));

        var line = $"{i++}. [{name}]({link}) ⭐ {stars:N0}";
        if (description.Length > 0) line += $"\n{description}";
        lines.Add(line);
    }

    return MakeEmbed($"GitHub repositories for \"{query}\"",
        $"https://github.com/search?q={Uri.EscapeDataString(query)}&type=repositories",
        lines, Color.DarkGrey);
}

async Task<Embed> SearchHackerNewsAsync(string query)
{
    var url = "https://hn.algolia.com/api/v1/search"
        + $"?tags=story&hitsPerPage=5&query={Uri.EscapeDataString(query)}";

    using var doc = await GetJsonAsync(url);

    var lines = new List<string>();
    var i = 1;
    foreach (var hit in doc.RootElement.GetProperty("hits").EnumerateArray())
    {
        var id = Str(hit, "objectID");
        var discussion = $"https://news.ycombinator.com/item?id={id}";
        var link = Str(hit, "url");
        if (link.Length == 0) link = discussion;

        var title = Format.Sanitize(Str(hit, "title"));
        var points = hit.TryGetProperty("points", out var p) && p.ValueKind == JsonValueKind.Number
            ? p.GetInt32() : 0;

        lines.Add($"{i++}. [{title}]({link}) ({points:N0} points, [discussion]({discussion}))");
    }

    return MakeEmbed($"Hacker News stories for \"{query}\"",
        $"https://hn.algolia.com/?q={Uri.EscapeDataString(query)}",
        lines, new Color(255, 102, 0));
}

// ---- Desktop Automation Helper ----
class DesktopAutomation
{
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern bool SetCursorPos(int x, int y);

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, int dwExtraInfo);

    private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    private const uint MOUSEEVENTF_LEFTUP = 0x0004;

    public static void ClickAt(int x, int y)
    {
        SetCursorPos(794 , 334);
        System.Threading.Thread.Sleep(50);
        mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
    }

    public static void TypeText(string text)
    {
        System.Windows.Forms.SendKeys.SendWait("text");
    }
}